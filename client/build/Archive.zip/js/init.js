$(document).ready(function() {
  App.init();
});